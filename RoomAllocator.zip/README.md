# Room Allocation System

Automatically allocates rooms when someone fills a Microsoft Form, updates the Excel sheet, and sends a WhatsApp confirmation message.

## Prerequisites

1. **Python 3.10+** — [Download here](https://www.python.org/downloads/)
   - During install, check **"Add Python to PATH"**
2. **Chrome browser** with **WhatsApp Web logged in**
   - Open [web.whatsapp.com](https://web.whatsapp.com) in Chrome
   - Scan QR code with your phone (one time only)
3. Your **Room Allocation Excel file** (.xlsx)

## Quick Start (2 minutes)

### Step 1: Run Setup (one time)

Double-click **`setup.bat`** — it will:
- Install all Python packages
- Ask you to configure your Excel file path, sheet name, etc.
- Create the `.env` config file

### Step 2: Start the System

Double-click **`start.bat`** — it will:
- Start the server (allocates rooms, updates Excel)
- Start the poller (watches for new form responses)
- Auto-send WhatsApp messages via your Chrome

### Step 3: Connect Microsoft Forms (one time)

1. Go to [forms.office.com](https://forms.office.com) → open your form
2. Click **Responses** tab → **Open in Excel**
3. Save the file as `FormResponses.xlsx` in this folder

Now every time someone fills the form, the system will:
1. Detect the new response
2. Find a vacant room (Single/Double)
3. Update the Excel sheet
4. Send a WhatsApp message to the guest

## How It Works

```
Microsoft Form
     ↓ (responses saved to Excel via OneDrive)
FormResponses.xlsx
     ↓ (poller checks every 15 seconds)
Python Server
     ↓
  ┌──┴──┐
  ↓     ↓
Excel  WhatsApp
update  message
```

## API Endpoints (for advanced use)

| Method | URL | Description |
|---|---|---|
| POST | `/webhook/form-response` | Submit guest data directly |
| GET | `/rooms` | List all rooms |
| GET | `/rooms/vacant?occupancy=Single` | List vacant rooms |
| POST | `/rooms/vacate` | Check out: `{"room_no": "Room no-101"}` |
| GET | `/health` | Server health check |

## Example: Manual room allocation

```bash
curl -X POST http://localhost:5000/webhook/form-response -H "Content-Type: application/json" -d "{\"Name\": \"John\", \"Contact No\": \"9876543210\", \"Occupancy\": \"Single\", \"Company\": \"Trident Group\"}"
```

## Configuration

All settings are in the `.env` file (created by setup):

| Setting | Description |
|---|---|
| `EXCEL_FILE_PATH` | Path to your room allocation Excel |
| `SHEET_NAME` | Sheet to use (Greenland, Woodland, etc.) |
| `RESPONSES_FILE` | Path to Microsoft Forms response Excel |
| `POLL_INTERVAL` | Seconds between checks for new responses |
| `FLASK_PORT` | Server port (default 5000) |

## File Structure

```
├── setup.bat              ← Run this first (one time)
├── start.bat              ← Run this daily to start the system
├── setup_config.py        ← Interactive config wizard
├── app.py                 ← Flask server
├── poller.py              ← Watches for new form responses
├── excel_manager.py       ← Excel read/write
├── whatsapp_notifier.py   ← WhatsApp auto-sender
├── config.py              ← Settings loader
├── create_template.py     ← Creates template Excel if needed
├── .env                   ← Your configuration (created by setup)
├── requirements.txt       ← Python packages
└── RoomAllocation.xlsx    ← Room allocation Excel
```

## Troubleshooting

- **WhatsApp not sending?** Make sure Chrome is open with WhatsApp Web logged in.
- **Room not allocated?** Check if there are vacant rooms: `http://localhost:5000/rooms/vacant`
- **Form responses not detected?** Check that `FormResponses.xlsx` exists and has data.
- **Change settings?** Edit `.env` file or re-run `setup.bat`.
