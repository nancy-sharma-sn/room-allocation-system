import os
import shutil
from datetime import datetime

from openpyxl import load_workbook

import config


def _load_workbook():
    return load_workbook(config.EXCEL_FILE_PATH)


def _save_workbook(wb):
    backup = config.EXCEL_FILE_PATH + ".bak"
    shutil.copy2(config.EXCEL_FILE_PATH, backup)
    wb.save(config.EXCEL_FILE_PATH)


def get_all_rooms(sheet_name=None):
    """Return a list of dicts for every room row in the sheet."""
    wb = _load_workbook()
    ws = wb[sheet_name or config.SHEET_NAME]
    col = config.COLUMN_MAP
    rooms = []

    for row in range(2, ws.max_row + 1):
        occupancy = ws.cell(row=row, column=col["occupancy"]).value
        room_no = ws.cell(row=row, column=col["room_no"]).value
        if not room_no:
            continue
        rooms.append({
            "row": row,
            "occupancy": (occupancy or "").strip(),
            "room_no": (room_no or "").strip(),
            "name": (ws.cell(row=row, column=col["name"]).value or "").strip(),
            "status": (ws.cell(row=row, column=col["status"]).value or "").strip(),
        })

    wb.close()
    return rooms


def find_vacant_room(occupancy_type, sheet_name=None):
    """Find the first vacant room matching the requested occupancy type.

    Returns the room dict or None.
    """
    rooms = get_all_rooms(sheet_name)
    occupancy_type = occupancy_type.strip().capitalize()

    for room in rooms:
        is_match = room["occupancy"].capitalize() == occupancy_type
        is_vacant = room["status"].lower() == "vacant" or room["status"] == ""
        if is_match and is_vacant:
            return room

    return None


def allocate_room(row, guest_data, sheet_name=None):
    """Write guest data into the given row, marking the room as Occupied."""
    wb = _load_workbook()
    ws = wb[sheet_name or config.SHEET_NAME]
    col = config.COLUMN_MAP

    ws.cell(row=row, column=col["name"], value=guest_data.get("name", ""))
    ws.cell(row=row, column=col["contact_no"], value=guest_data.get("contact_no", ""))
    ws.cell(row=row, column=col["salary_code"], value=guest_data.get("salary_code", ""))
    ws.cell(row=row, column=col["holder_code"], value=guest_data.get("holder_code", ""))
    ws.cell(row=row, column=col["status"], value="Occupied")
    ws.cell(row=row, column=col["type_of_stay"], value=guest_data.get("type_of_stay", "Temporary"))
    ws.cell(row=row, column=col["company"], value=guest_data.get("company", ""))
    ws.cell(row=row, column=col["business"], value=guest_data.get("business", ""))

    check_in = guest_data.get("check_in") or datetime.now().strftime("%d-%m-%Y")
    ws.cell(row=row, column=col["check_in"], value=check_in)

    check_in_time = guest_data.get("check_in_time") or datetime.now().strftime("%I:%M %p")
    ws.cell(row=row, column=col["check_in_time"], value=check_in_time)

    ws.cell(row=row, column=col["check_out"], value=guest_data.get("check_out", ""))
    ws.cell(row=row, column=col["check_out_time"], value=guest_data.get("check_out_time", ""))
    ws.cell(row=row, column=col["requestor"], value=guest_data.get("requestor", ""))
    ws.cell(row=row, column=col["approval"], value=guest_data.get("approval", ""))

    _save_workbook(wb)
    wb.close()


def vacate_room(room_no, sheet_name=None):
    """Mark a room as Vacant and clear guest data."""
    wb = _load_workbook()
    ws = wb[sheet_name or config.SHEET_NAME]
    col = config.COLUMN_MAP

    for row in range(2, ws.max_row + 1):
        cell_val = (ws.cell(row=row, column=col["room_no"]).value or "").strip()
        if cell_val == room_no.strip():
            for field in ["name", "contact_no", "salary_code", "holder_code",
                          "type_of_stay", "company", "business",
                          "check_in", "check_in_time", "check_out",
                          "check_out_time", "requestor", "approval"]:
                ws.cell(row=row, column=col[field], value="")
            ws.cell(row=row, column=col["status"], value="Vacant")
            _save_workbook(wb)
            wb.close()
            return True

    wb.close()
    return False
