"""
WhatsApp Notifier — uses existing Chrome session with WhatsApp Web.
Opens the chat URL in Chrome (already logged in), waits for load, auto-sends.
"""

import logging
import subprocess
import threading
import time
from urllib.parse import quote

logger = logging.getLogger(__name__)


def _normalize_phone(phone: str) -> str:
    phone = str(phone).strip().replace(" ", "").replace("-", "").replace("+", "")
    if phone.startswith("0"):
        phone = phone[1:]
    if len(phone) == 10:
        phone = "91" + phone
    return phone


def _send_message(phone: str, message: str):
    """Open WhatsApp Web chat in default browser, wait for load, auto-click Send."""
    import webbrowser
    import pyautogui
    pyautogui.FAILSAFE = False

    encoded_msg = quote(message)
    url = f"https://web.whatsapp.com/send?phone={phone}&text={encoded_msg}"

    webbrowser.open(url)
    logger.info("Opened WhatsApp chat for %s in browser", phone)

    time.sleep(25)

    pyautogui.hotkey("alt", "tab")
    time.sleep(2)
    pyautogui.press("enter")
    logger.info("Pressed Enter to send message to %s", phone)

    time.sleep(5)
    pyautogui.hotkey("ctrl", "w")
    logger.info("Closed tab. Message sent to %s!", phone)


def send_room_confirmation(phone_number: str, guest_name: str,
                           room_no: str, check_in: str,
                           occupancy: str, company: str,
                           location: str = "") -> bool:
    phone = _normalize_phone(phone_number)

    message = (
        f"Hello {guest_name},\n\n"
        f"Your room has been successfully allocated!\n\n"
        f"*Room Details*\n"
        f"-------------------\n"
        f"Building: *{location}*\n"
        f"Room Number: *{room_no}*\n"
        f"Occupancy: {occupancy}\n"
        f"Company: {company}\n"
        f"Check-in Date: {check_in}\n"
        f"-------------------\n\n"
        f"Please carry a valid ID proof at the time of check-in.\n\n"
        f"For any queries, contact the admin office.\n"
        f"Thank you!"
    )

    try:
        thread = threading.Thread(target=_send_message, args=(phone, message), daemon=True)
        thread.start()
        thread.join(timeout=60)
        return True
    except Exception as exc:
        logger.error("Failed to send WhatsApp: %s", exc)
        return False


def initialize():
    logger.info("WhatsApp will use existing Chrome session (already logged in).")
    return True
