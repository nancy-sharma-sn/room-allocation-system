"""
Form Response Poller
====================
Watches the Microsoft Forms response Excel file (synced via OneDrive) for new
entries. When a new response is detected, allocates a room, updates the main
Excel sheet, and sends a WhatsApp confirmation.

No ngrok, no public URL, no Power Automate HTTP connector needed.
Everything runs locally on your machine.

Usage:
    python poller.py
"""

import logging
import os
import time
from datetime import datetime

from openpyxl import load_workbook

import config
from excel_manager import allocate_room, find_vacant_room
from whatsapp_notifier import send_room_confirmation

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

RESPONSES_FILE = os.getenv("RESPONSES_FILE", "./FormResponses.xlsx")
POLL_INTERVAL = int(os.getenv("POLL_INTERVAL", 15))
PROCESSED_LOG = "./processed_responses.txt"

SEARCH_FOLDERS = [
    os.path.dirname(os.path.abspath(__file__)),
    os.path.expanduser("~\\Downloads"),
    os.path.expanduser("~\\OneDrive"),
    os.path.expanduser("~\\OneDrive - AMDOCS"),
    os.path.expanduser("~\\Documents"),
]

RESPONSE_FIELD_MAP = {
    "name": ["Name", "Full Name", "name", "Guest Name"],
    "contact_no": ["Contact No", "Contact Number", "Phone", "Mobile", "Phone Number", "contact no"],
    "salary_code": ["Salary Code", "salary code"],
    "holder_code": ["Badge Holder Code", "Holder Code", "holder code"],
    "occupancy": ["Occupancy", "Occupancy Type", "Room Type", "occupancy"],
    "type_of_stay": ["Type of Stay", "Stay Type", "type of stay"],
    "company": ["Company", "company", "Organization"],
    "business": ["Business", "business", "Purpose"],
    "check_in": ["Check in", "Check In Date", "Check-in Date", "check in"],
    "check_in_time": ["Check in Time", "Check In Time"],
    "check_out": ["Check out", "Check Out Date", "Check-out Date", "check out"],
    "check_out_time": ["Check Out Time", "Check out Time"],
    "requestor": ["Requestor", "Requested By", "requestor"],
    "approval": ["Approval", "approval"],
}


def _load_processed_ids() -> set:
    """Load already-processed response IDs from the log file."""
    if not os.path.exists(PROCESSED_LOG):
        return set()
    with open(PROCESSED_LOG, "r") as f:
        return {line.strip() for line in f if line.strip()}


def _save_processed_id(response_id: str):
    """Append a processed response ID to the log file."""
    with open(PROCESSED_LOG, "a") as f:
        f.write(response_id + "\n")


def _find_responses_file() -> str:
    """Auto-find the form responses Excel file across common locations."""
    if os.path.exists(RESPONSES_FILE):
        return RESPONSES_FILE

    for folder in SEARCH_FOLDERS:
        if not os.path.isdir(folder):
            continue
        for root, dirs, files in os.walk(folder):
            depth = root.replace(folder, "").count(os.sep)
            if depth > 2:
                dirs.clear()
                continue
            for f in files:
                if f.endswith(".xlsx") and "response" in f.lower():
                    return os.path.join(root, f)
                if f.endswith(".xlsx") and "form" in f.lower():
                    return os.path.join(root, f)
    return RESPONSES_FILE


def _map_row_to_guest(headers: list, row_values: list) -> dict:
    """Map a response row to guest data using flexible header matching."""
    header_to_value = {}
    for i, header in enumerate(headers):
        if header and i < len(row_values):
            header_to_value[str(header).strip()] = row_values[i]

    guest = {}
    for internal_key, possible_headers in RESPONSE_FIELD_MAP.items():
        for ph in possible_headers:
            if ph in header_to_value and header_to_value[ph]:
                val = header_to_value[ph]
                if isinstance(val, datetime):
                    guest[internal_key] = val.strftime("%d-%m-%Y")
                else:
                    guest[internal_key] = str(val).strip()
                break

    return guest


def _generate_response_id(row_values: list) -> str:
    """Generate a unique ID for a response row based on name + contact + timestamp."""
    parts = []
    for v in row_values[:5]:
        if v is not None:
            parts.append(str(v).strip())
    return "|".join(parts)


def read_new_responses() -> list:
    """Read the Microsoft Forms response Excel and return unprocessed entries."""
    responses_path = _find_responses_file()

    if not os.path.exists(responses_path):
        return []

    try:
        wb = load_workbook(responses_path, read_only=True, data_only=True)
    except Exception as exc:
        logger.warning("Could not open responses file (may be locked by OneDrive): %s", exc)
        return []

    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()

    if len(rows) < 2:
        return []

    headers = [str(h).strip() if h else "" for h in rows[0]]
    processed = _load_processed_ids()
    new_responses = []

    for row_values in rows[1:]:
        if not any(row_values):
            continue

        response_id = _generate_response_id(list(row_values))
        if response_id in processed:
            continue

        guest = _map_row_to_guest(headers, list(row_values))
        if guest.get("name"):
            guest["_response_id"] = response_id
            new_responses.append(guest)

    return new_responses


def process_response(guest: dict):
    """Allocate a room for a guest, update Excel, and send WhatsApp."""
    name = guest.get("name", "Unknown")
    contact = guest.get("contact_no", "")
    occupancy = guest.get("occupancy", "Single")

    logger.info("Processing: %s (%s) — requesting %s room", name, contact, occupancy)

    room = find_vacant_room(occupancy, config.SHEET_NAME)
    if not room:
        logger.warning("No vacant %s room for %s — trying any available room", occupancy, name)
        alt = "Double" if occupancy == "Single" else "Single"
        room = find_vacant_room(alt, config.SHEET_NAME)

    if not room:
        logger.error("NO rooms available for %s!", name)
        return

    allocate_room(room["row"], guest, config.SHEET_NAME)
    logger.info("Allocated %s to %s", room["room_no"], name)

    if contact:
        check_in = guest.get("check_in", datetime.now().strftime("%d-%m-%Y"))
        send_room_confirmation(
            phone_number=contact,
            guest_name=name,
            room_no=room["room_no"],
            check_in=check_in,
            occupancy=room["occupancy"],
            company=guest.get("company", "N/A"),
        )
    else:
        logger.warning("No contact number for %s — skipping WhatsApp", name)


def run_poller():
    """Main polling loop."""
    logger.info("=" * 60)
    logger.info("  Room Allocation Poller Started")
    logger.info("  Watching: %s", os.path.abspath(RESPONSES_FILE))
    logger.info("  Main Excel: %s", os.path.abspath(config.EXCEL_FILE_PATH))
    logger.info("  Sheet: %s", config.SHEET_NAME)
    logger.info("  Poll interval: %s seconds", POLL_INTERVAL)
    logger.info("=" * 60)

    while True:
        try:
            new_responses = read_new_responses()

            if new_responses:
                logger.info("Found %d new response(s)!", len(new_responses))

            for guest in new_responses:
                response_id = guest.pop("_response_id", "")
                try:
                    process_response(guest)
                    _save_processed_id(response_id)
                except Exception as exc:
                    logger.error("Error processing %s: %s", guest.get("name"), exc)

            if not new_responses:
                logger.debug("No new responses. Waiting %ds...", POLL_INTERVAL)

        except KeyboardInterrupt:
            logger.info("Poller stopped by user.")
            break
        except Exception as exc:
            logger.error("Polling error: %s", exc)

        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    run_poller()
