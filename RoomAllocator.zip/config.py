import os
from dotenv import load_dotenv

load_dotenv()

EXCEL_FILE_PATH = os.getenv("EXCEL_FILE_PATH", "./RoomAllocation.xlsx")
SHEET_NAME = os.getenv("SHEET_NAME", "Greenland")
FLASK_PORT = int(os.getenv("FLASK_PORT", 5000))

COLUMN_MAP = {
    "occupancy": 1,       # A
    "room_no": 2,         # B
    "name": 3,            # C
    "contact_no": 4,      # D
    "salary_code": 5,     # E
    "holder_code": 6,     # F
    "status": 7,          # G
    "type_of_stay": 8,    # H
    "company": 9,         # I
    "business": 10,       # J
    "check_in": 11,       # K
    "check_in_time": 12,  # L
    "check_out": 13,      # M
    "check_out_time": 14, # N
    "requestor": 15,      # O
    "approval": 16,       # P
}
