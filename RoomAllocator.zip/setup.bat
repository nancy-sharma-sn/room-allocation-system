@echo off
title Room Allocation System - Setup
echo ============================================
echo   Room Allocation System - One Time Setup
echo ============================================
echo.

:: Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed!
    echo Download from: https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)
echo [OK] Python found.

:: Install dependencies
echo.
echo Installing required packages...
pip install flask openpyxl requests python-dotenv pyautogui selenium webdriver-manager >nul 2>&1
echo [OK] Packages installed.

:: Run config wizard
echo.
python setup_config.py

echo.
echo ============================================
echo   Setup complete! Run start.bat to begin.
echo ============================================
pause
