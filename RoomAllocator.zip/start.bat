@echo off
title Room Allocation System
echo ============================================
echo   Room Allocation System - Starting...
echo ============================================
echo.

:: Check if .env exists
if not exist ".env" (
    echo [!] First time? Running setup...
    call setup.bat
)

echo Starting server + poller...
echo.
echo   Server:  http://localhost:5000
echo   Poller:  Watching for new form responses
echo   WhatsApp: Auto-send via Chrome
echo.
echo   Press Ctrl+C to stop.
echo ============================================
echo.

start /b python app.py
python poller.py
