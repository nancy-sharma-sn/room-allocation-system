"""Interactive setup wizard — creates .env file with user's settings."""

import os

print("=" * 50)
print("  Room Allocation System - Setup")
print("=" * 50)
print()

excel_path = input(
    "Path to your Room Allocation Excel file\n"
    "  (drag & drop the file here, or press Enter for default): "
).strip().strip('"')

if not excel_path:
    if os.path.exists("./RoomAllocation.xlsx"):
        excel_path = "./RoomAllocation.xlsx"
        print(f"  Using existing: {excel_path}")
    else:
        print("  No Excel found — creating a template...")
        excel_path = "./RoomAllocation.xlsx"
        import create_template
        print("  Template created with sheets: Greenland, Woodland, ORC, Admin")
elif not os.path.exists(excel_path):
    print(f"  [WARNING] File not found: {excel_path}")
    print("  You can fix this later in the .env file.")

print()
port = input(
    "Server port (press Enter for 5000): "
).strip()
if not port:
    port = "5000"

env_content = f"""EXCEL_FILE_PATH={excel_path}
SHEET_NAME=Greenland
FLASK_PORT={port}
"""

with open(".env", "w") as f:
    f.write(env_content)

print()
print("[OK] Setup complete!")
print()
print(f"  Excel file:  {excel_path}")
print(f"  Server port: {port}")
print()
print("  NOTE: The building (Greenland, Woodland, ORC, Admin)")
print("  is selected automatically in the form by the person")
print("  requesting the room. No need to configure it here.")
