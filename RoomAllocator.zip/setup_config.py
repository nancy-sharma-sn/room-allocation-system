"""Interactive setup wizard — creates .env file with user's settings."""

import os
import shutil

print("=" * 50)
print("  Configuration Wizard")
print("=" * 50)
print()

excel_path = input(
    "Path to your Room Allocation Excel file\n"
    "  (drag & drop the file here, or press Enter for default): "
).strip().strip('"')

if not excel_path:
    if os.path.exists("./RoomAllocation.xlsx"):
        excel_path = "./RoomAllocation.xlsx"
        print(f"  Using existing: {excel_path}")
    else:
        print("  No Excel found — a template will be created.")
        excel_path = "./RoomAllocation.xlsx"
        import create_template
        print("  Template created!")
elif not os.path.exists(excel_path):
    print(f"  [WARNING] File not found: {excel_path}")
    print("  You can fix this later in the .env file.")

print()
sheet = input(
    "Sheet name to use (e.g. Greenland, Woodland, ORC, Admin)\n"
    "  Press Enter for 'Greenland': "
).strip()
if not sheet:
    sheet = "Greenland"

print()
responses = input(
    "Path to the Form Responses Excel (from Microsoft Forms)\n"
    "  (drag & drop, or press Enter to skip for now): "
).strip().strip('"')
if not responses:
    responses = "./FormResponses.xlsx"

print()
interval = input(
    "How often to check for new responses (seconds)?\n"
    "  Press Enter for 15: "
).strip()
if not interval:
    interval = "15"

print()
port = input(
    "Server port (press Enter for 5000): "
).strip()
if not port:
    port = "5000"

env_content = f"""EXCEL_FILE_PATH={excel_path}
SHEET_NAME={sheet}

RESPONSES_FILE={responses}
POLL_INTERVAL={interval}

FLASK_PORT={port}
"""

with open(".env", "w") as f:
    f.write(env_content)

print()
print("[OK] Configuration saved to .env")
print()
print("Your settings:")
print(f"  Excel file:     {excel_path}")
print(f"  Sheet:          {sheet}")
print(f"  Responses file: {responses}")
print(f"  Poll interval:  {interval}s")
print(f"  Server port:    {port}")
