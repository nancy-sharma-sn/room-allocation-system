"""One-time script to create a template Excel file matching the room allocation structure."""

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

wb = Workbook()

HEADERS = [
    "Occupancy", "Room no", "Name", "Contact No.", "Salary Code",
    "Holder Code", "Status", "Type of Stay", "Company", "Business",
    "Check in", "Check in Time", "Check out", "Check Out Time",
    "Requestor", "Approval",
]

ROOMS = [
    ("Single", "Room no-101"), ("Double", "Room no-102"), ("Double", "Room no-103"),
    ("Single", "Room no-104"), ("Single", "Room no-105"), ("Double", "Room no-106"),
    ("Double", "Room no-107"), ("Double", "Room no-108"), ("Single", "Room no-109"),
    ("Double", "Room no-201"), ("Double", "Room no-202"), ("Double", "Room no-203"),
    ("Single", "Room no-204"), ("Single", "Room no-205"), ("Double", "Room no-206"),
    ("Double", "Room no-207"), ("Double", "Room no-208"), ("Single", "Room no-209"),
    ("Double", "Room no-210"), ("Double", "Room no-301"), ("Single", "Room no-302"),
    ("Double", "Room no-303"), ("Single", "Room no-304"), ("Single", "Room no-305"),
    ("Double", "Room no-306"), ("Double", "Room no-307"), ("Single", "Room no-308"),
    ("Single", "Room no-309"), ("Double", "Room no-401"), ("Double", "Room no-402"),
    ("Single", "Room no-403"), ("Double", "Room no-404"), ("Double", "Room no-405"),
]

header_font = Font(bold=True, size=11)
header_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
thin_border = Border(
    left=Side(style="thin"), right=Side(style="thin"),
    top=Side(style="thin"), bottom=Side(style="thin"),
)

for sheet_name in ["Greenland", "Woodland", "ORC", "Admin"]:
    if sheet_name == "Greenland":
        ws = wb.active
        ws.title = sheet_name
    else:
        ws = wb.create_sheet(sheet_name)

    for col_idx, header in enumerate(HEADERS, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.border = thin_border
        cell.alignment = Alignment(horizontal="center")

    for row_idx, (occupancy, room_no) in enumerate(ROOMS, 2):
        ws.cell(row=row_idx, column=1, value=occupancy).border = thin_border
        ws.cell(row=row_idx, column=2, value=room_no).border = thin_border
        ws.cell(row=row_idx, column=7, value="Vacant").border = thin_border
        for col_idx in range(3, 17):
            if col_idx != 7:
                ws.cell(row=row_idx, column=col_idx).border = thin_border

    ws.column_dimensions["A"].width = 12
    ws.column_dimensions["B"].width = 15
    ws.column_dimensions["C"].width = 20
    ws.column_dimensions["D"].width = 15
    ws.column_dimensions["E"].width = 12
    ws.column_dimensions["F"].width = 14
    ws.column_dimensions["G"].width = 10
    ws.column_dimensions["H"].width = 15
    ws.column_dimensions["I"].width = 18
    ws.column_dimensions["J"].width = 12
    ws.column_dimensions["K"].width = 12
    ws.column_dimensions["L"].width = 14
    ws.column_dimensions["M"].width = 12
    ws.column_dimensions["N"].width = 14
    ws.column_dimensions["O"].width = 15
    ws.column_dimensions["P"].width = 12

if "Sheet" in wb.sheetnames:
    del wb["Sheet"]

wb.save("RoomAllocation.xlsx")
print("Created RoomAllocation.xlsx with sheets: Greenland, Woodland, ORC, Admin")
print(f"Total rooms per sheet: {len(ROOMS)}")
