"""
Room Allocation System
======================
Built-in web form + API. Anyone on the network fills the form at
http://<ip>:5000/form → room allocated → Excel updated → WhatsApp sent.
"""

import logging
from datetime import datetime

from flask import Flask, jsonify, request, redirect

import config
from excel_manager import allocate_room, find_vacant_room, get_all_rooms, vacate_room
from whatsapp_notifier import send_room_confirmation, initialize as init_whatsapp

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)

app = Flask(__name__)


FORM_FIELD_MAP = {
    "Name": "name",
    "Contact No": "contact_no",
    "Contact Number": "contact_no",
    "Location": "location",
    "Building": "location",
    "Salary Code": "salary_code",
    "Badge Holder Code": "holder_code",
    "Holder Code": "holder_code",
    "Occupancy": "occupancy",
    "Occupancy Type": "occupancy",
    "Type of Stay": "type_of_stay",
    "Company": "company",
    "Business": "business",
    "Check in": "check_in",
    "Check In Date": "check_in",
    "Check in Time": "check_in_time",
    "Check out": "check_out",
    "Check Out Date": "check_out",
    "Check Out Time": "check_out_time",
    "Requestor": "requestor",
    "Approval": "approval",
}


def _normalize_form_data(raw: dict) -> dict:
    normalized = {}
    for form_key, value in raw.items():
        internal_key = FORM_FIELD_MAP.get(form_key)
        if internal_key and value:
            normalized[internal_key] = str(value).strip()
    return normalized


def _allocate_and_notify(guest: dict):
    """Core logic: find room, update Excel, send WhatsApp."""
    occupancy = guest.get("occupancy", "Single")
    sheet = guest.get("location") or config.SHEET_NAME
    room = find_vacant_room(occupancy, sheet)
    if not room:
        return None, False

    allocate_room(room["row"], guest, sheet)
    logger.info("Allocated %s to %s", room["room_no"], guest["name"])

    whatsapp_sent = send_room_confirmation(
        phone_number=guest["contact_no"],
        guest_name=guest["name"],
        room_no=room["room_no"],
        check_in=guest.get("check_in", datetime.now().strftime("%d-%m-%Y")),
        occupancy=occupancy,
        company=guest.get("company", "N/A"),
        location=sheet,
    )
    return room, whatsapp_sent


# ─── BUILT-IN WEB FORM ──────────────────────────────────────────────────────

FORM_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Room Allocation Request</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #f0f2f5; min-height: 100vh; display: flex; justify-content: center; padding: 30px 15px; }
  .container { background: white; border-radius: 12px; box-shadow: 0 2px 20px rgba(0,0,0,0.08); max-width: 600px; width: 100%; padding: 40px; }
  h1 { color: #1a73e8; font-size: 24px; margin-bottom: 8px; }
  .subtitle { color: #666; margin-bottom: 30px; font-size: 14px; }
  .form-group { margin-bottom: 20px; }
  label { display: block; font-weight: 600; color: #333; margin-bottom: 6px; font-size: 14px; }
  label .req { color: #e74c3c; }
  input, select { width: 100%; padding: 12px; border: 1.5px solid #ddd; border-radius: 8px; font-size: 15px; transition: border 0.2s; }
  input:focus, select:focus { outline: none; border-color: #1a73e8; box-shadow: 0 0 0 3px rgba(26,115,232,0.1); }
  .row { display: flex; gap: 15px; }
  .row .form-group { flex: 1; }
  button { width: 100%; padding: 14px; background: #1a73e8; color: white; border: none; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; margin-top: 10px; transition: background 0.2s; }
  button:hover { background: #1557b0; }
  .footer { text-align: center; color: #999; font-size: 12px; margin-top: 20px; }
</style>
</head>
<body>
<div class="container">
  <h1>Room Allocation Request</h1>
  <p class="subtitle">Fill this form to get a room allocated. You'll receive a WhatsApp confirmation.</p>
  <form action="/form/submit" method="POST">
    <div class="row">
      <div class="form-group">
        <label>Full Name <span class="req">*</span></label>
        <input type="text" name="name" required placeholder="e.g. Harsh Kumar">
      </div>
      <div class="form-group">
        <label>Contact Number <span class="req">*</span></label>
        <input type="tel" name="contact_no" required placeholder="e.g. 9876543210" pattern="[0-9]{10,12}">
      </div>
    </div>
    <div class="form-group">
      <label>Building / Location <span class="req">*</span></label>
      <select name="location" required>
        <option value="">-- Select Building --</option>
        <option value="Greenland">Greenland</option>
        <option value="Woodland">Woodland</option>
        <option value="ORC">ORC</option>
        <option value="Admin">Admin</option>
      </select>
    </div>
    <div class="row">
      <div class="form-group">
        <label>Occupancy <span class="req">*</span></label>
        <select name="occupancy" required>
          <option value="Single">Single</option>
          <option value="Double">Double</option>
        </select>
      </div>
      <div class="form-group">
        <label>Type of Stay</label>
        <select name="type_of_stay">
          <option value="Temporary">Temporary</option>
          <option value="Permanent">Permanent</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="form-group">
        <label>Company</label>
        <input type="text" name="company" placeholder="e.g. Trident Group">
      </div>
      <div class="form-group">
        <label>Business</label>
        <input type="text" name="business" placeholder="e.g. Corporate">
      </div>
    </div>
    <div class="row">
      <div class="form-group">
        <label>Salary Code</label>
        <input type="text" name="salary_code" placeholder="e.g. 45012">
      </div>
      <div class="form-group">
        <label>Badge Holder Code</label>
        <select name="holder_code">
          <option value="">-- Select --</option>
          <option value="KV">KV</option>
          <option value="FLE">FLE</option>
          <option value="KV2">KV2</option>
          <option value="Contractor">Contractor</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="form-group">
        <label>Check-in Date</label>
        <input type="date" name="check_in">
      </div>
      <div class="form-group">
        <label>Check-out Date</label>
        <input type="date" name="check_out">
      </div>
    </div>
    <div class="form-group">
      <label>Requestor</label>
      <input type="text" name="requestor" placeholder="Who is requesting?">
    </div>
    <button type="submit">Submit Request</button>
  </form>
  <p class="footer">Room Allocation System</p>
</div>
</body>
</html>"""


SUCCESS_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Room Allocated!</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #f0f2f5; min-height: 100vh; display: flex; justify-content: center; align-items: center; padding: 30px 15px; }
  .container { background: white; border-radius: 12px; box-shadow: 0 2px 20px rgba(0,0,0,0.08); max-width: 500px; width: 100%; padding: 40px; text-align: center; }
  .check { font-size: 60px; margin-bottom: 15px; }
  h1 { color: #27ae60; font-size: 24px; margin-bottom: 20px; }
  .details { background: #f8f9fa; border-radius: 8px; padding: 20px; text-align: left; margin: 20px 0; }
  .details p { margin: 8px 0; font-size: 15px; color: #333; }
  .details strong { color: #1a73e8; }
  .whatsapp { color: #27ae60; font-weight: 600; margin: 15px 0; }
  a { display: inline-block; margin-top: 20px; padding: 12px 30px; background: #1a73e8; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; }
  a:hover { background: #1557b0; }
</style>
</head>
<body>
<div class="container">
  <div class="check">&#10003;</div>
  <h1>Room Allocated Successfully!</h1>
  <div class="details">
    <p><strong>Guest:</strong> {name}</p>
    <p><strong>Building:</strong> {location}</p>
    <p><strong>Room:</strong> {room}</p>
    <p><strong>Occupancy:</strong> {occupancy}</p>
    <p><strong>Check-in:</strong> {checkin}</p>
  </div>
  <p class="whatsapp">{whatsapp_msg}</p>
  <a href="/form">Submit Another Request</a>
</div>
</body>
</html>"""


ERROR_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Error</title>
<style>
  body {{ font-family: 'Segoe UI', sans-serif; background: #f0f2f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; }}
  .container {{ background: white; border-radius: 12px; box-shadow: 0 2px 20px rgba(0,0,0,0.08); max-width: 500px; padding: 40px; text-align: center; }}
  h1 {{ color: #e74c3c; margin-bottom: 15px; }}
  p {{ color: #666; margin-bottom: 20px; }}
  a {{ display: inline-block; padding: 12px 30px; background: #1a73e8; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; }}
</style>
</head>
<body>
<div class="container">
  <h1>{title}</h1>
  <p>{message}</p>
  <a href="/form">Go Back</a>
</div>
</body>
</html>"""


@app.route("/")
def index():
    return redirect("/form")


@app.route("/form")
def show_form():
    return FORM_HTML


@app.route("/form/submit", methods=["POST"])
def submit_form():
    """Handle the built-in web form submission."""
    guest = {
        "name": request.form.get("name", "").strip(),
        "contact_no": request.form.get("contact_no", "").strip(),
        "location": request.form.get("location", "").strip(),
        "occupancy": request.form.get("occupancy", "Single"),
        "type_of_stay": request.form.get("type_of_stay", "Temporary"),
        "company": request.form.get("company", "").strip(),
        "business": request.form.get("business", "").strip(),
        "salary_code": request.form.get("salary_code", "").strip(),
        "holder_code": request.form.get("holder_code", "").strip(),
        "check_in": request.form.get("check_in", "").strip(),
        "check_out": request.form.get("check_out", "").strip(),
        "requestor": request.form.get("requestor", "").strip(),
    }

    if not guest["name"] or not guest["contact_no"]:
        return ERROR_HTML.format(title="Missing Info", message="Name and Contact Number are required."), 400

    if guest["check_in"]:
        try:
            d = datetime.strptime(guest["check_in"], "%Y-%m-%d")
            guest["check_in"] = d.strftime("%d-%m-%Y")
        except ValueError:
            pass
    if guest["check_out"]:
        try:
            d = datetime.strptime(guest["check_out"], "%Y-%m-%d")
            guest["check_out"] = d.strftime("%d-%m-%Y")
        except ValueError:
            pass

    room, whatsapp_sent = _allocate_and_notify(guest)

    if not room:
        return ERROR_HTML.format(
            title="No Rooms Available",
            message=f"No vacant {guest['occupancy']} rooms in {guest.get('location', 'selected building')}. Try a different type or building."
        ), 409

    wa_msg = "WhatsApp confirmation sent!" if whatsapp_sent else "WhatsApp not sent (check Chrome)."

    return SUCCESS_HTML.format(
        name=guest["name"],
        location=guest.get("location", "N/A"),
        room=room["room_no"],
        occupancy=guest["occupancy"],
        checkin=guest.get("check_in") or datetime.now().strftime("%d-%m-%Y"),
        whatsapp_msg=wa_msg,
    )


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "time": datetime.now().isoformat()})


@app.route("/webhook/form-response", methods=["POST"])
def handle_form_response():
    """API endpoint for JSON submissions (Power Automate / programmatic use)."""
    raw_data = request.get_json(silent=True) or {}
    logger.info("Received form data: %s", raw_data)

    guest = _normalize_form_data(raw_data)

    if not guest.get("name"):
        return jsonify({"error": "Name is required"}), 400
    if not guest.get("contact_no"):
        return jsonify({"error": "Contact number is required"}), 400

    room, whatsapp_sent = _allocate_and_notify(guest)
    if not room:
        occupancy = guest.get("occupancy", "Single")
        return jsonify({"error": f"No vacant {occupancy} room available"}), 409

    return jsonify({
        "success": True,
        "room_allocated": room["room_no"],
        "occupancy": guest.get("occupancy", "Single"),
        "guest_name": guest["name"],
        "whatsapp_sent": whatsapp_sent,
    }), 200


@app.route("/rooms", methods=["GET"])
def list_rooms():
    sheet = request.args.get("sheet", config.SHEET_NAME)
    return jsonify(get_all_rooms(sheet))


@app.route("/rooms/vacant", methods=["GET"])
def list_vacant_rooms():
    sheet = request.args.get("sheet", config.SHEET_NAME)
    occupancy = request.args.get("occupancy", "")
    rooms = get_all_rooms(sheet)
    vacant = [
        r for r in rooms
        if r["status"].lower() in ("vacant", "")
        and (not occupancy or r["occupancy"].lower() == occupancy.lower())
    ]
    return jsonify(vacant)


@app.route("/rooms/vacate", methods=["POST"])
def vacate():
    data = request.get_json(silent=True) or {}
    room_no = data.get("room_no", "").strip()
    if not room_no:
        return jsonify({"error": "room_no is required"}), 400
    sheet = data.get("sheet", config.SHEET_NAME)
    success = vacate_room(room_no, sheet)
    if success:
        return jsonify({"success": True, "room_no": room_no, "status": "Vacant"})
    return jsonify({"error": f"Room {room_no} not found"}), 404


if __name__ == "__main__":
    logger.info("Starting Room Allocation Server on port %s", config.FLASK_PORT)
    init_whatsapp()
    import socket
    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)
    logger.info("=" * 55)
    logger.info("  FORM URL:  http://%s:%s/form", local_ip, config.FLASK_PORT)
    logger.info("  Share this URL with anyone on the network!")
    logger.info("=" * 55)
    app.run(host="0.0.0.0", port=config.FLASK_PORT, debug=False)
